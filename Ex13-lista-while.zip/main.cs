using System;

class Program
{
    static void Main(string[] args)
    {
        int primeiro, segundo;

        // Solicita ao usuário os dois números, garantindo que o primeiro seja maior que o segundo
        do
        {
            Console.WriteLine("Digite o primeiro número (maior que o segundo):");
            primeiro = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o segundo número:");
            segundo = int.Parse(Console.ReadLine());

            if (primeiro <= segundo)
            {
                Console.WriteLine("O primeiro número deve ser maior que o segundo. Tente novamente.");
            }

        } while (primeiro <= segundo);

        // Variável para armazenar o resultado da subtração
        int resultado = 0;

        // Loop para realizar a subtração simulada usando apenas o operador de adição
        do
        {
            resultado++; // Incrementa o resultado em 1
            segundo++;   // Decrementa o segundo número em 1
        } while (segundo != 0);

        // Exibe o resultado da subtração
        Console.WriteLine("A subtração de " + primeiro + " e " + (primeiro - resultado) + " é: " + resultado);
    }
}
